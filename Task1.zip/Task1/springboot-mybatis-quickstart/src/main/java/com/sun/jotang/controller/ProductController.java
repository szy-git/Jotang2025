package com.sun.jotang.controller;

import com.sun.jotang.pojo.Product;
import com.sun.jotang.pojo.Result;
import com.sun.jotang.service.ProductService;
import org.apache.ibatis.annotations.Insert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class ProductController {
    @Autowired
    private ProductService productService;
    //新增商品信息

    @PostMapping("products")
    public Result insert(@RequestBody Product product){
        System.out.println("新增商品信息:"+product);
        productService.insert(product);
        return Result.success();

    }
    //删除商品信息
    @DeleteMapping("products/{id}")
    public Result deleteById(@PathVariable Integer id){
        System.out.println("根据id删除商品:"+id);
        productService.deleteById(id);
        return Result.success();
    }
    //修改商品信息
    @PutMapping("products")
    public Result updateById(@RequestBody Product product){
        System.out.println("修改商品信息");
        productService.update(product);
        return Result.success();
    }

    //查询商品详情
    @GetMapping("/products")
    public Result list(){
        System.out.println("查询商品信息");
        List<Product> productList = productService.list();
        return Result.success(productList);
    }
    @GetMapping("/products/{id}")
    public Result selectById(@PathVariable Integer id){
        System.out.println("根据id查询商品信息:"+id);
    productService.selectById(id);
    return Result.success();
    }


}
