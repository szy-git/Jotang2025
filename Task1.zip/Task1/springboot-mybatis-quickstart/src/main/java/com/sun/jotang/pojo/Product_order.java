package com.sun.jotang.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product_order {
    private Integer id;
    private Integer product_id;
    private Integer buyer_id;
    private String status;
    private LocalDateTime create_time;
    private LocalDateTime update_time;
}
