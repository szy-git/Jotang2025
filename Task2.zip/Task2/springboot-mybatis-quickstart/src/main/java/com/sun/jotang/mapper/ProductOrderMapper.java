package com.sun.jotang.mapper;

import com.sun.jotang.pojo.ProductOrder;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductOrderMapper {
    // 创建订单
    void insert(ProductOrder order);

    // 更新订单状态（用于取消订单）
    void update(ProductOrder order);

}
