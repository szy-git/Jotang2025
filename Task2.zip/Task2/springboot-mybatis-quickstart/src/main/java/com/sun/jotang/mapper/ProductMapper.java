package com.sun.jotang.mapper;

import com.sun.jotang.pojo.Product;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ProductMapper {
    //新增商品信息
    @Insert("insert into product(title, description, type, price, status, publisher_id,publish_time,update_time) values(#{title},#{description},#{type},#{price},#{status},#{publisherId},#{publishTime},#{updateTime}) ")
    void insert(Product product);
    //删除商品信息
    @Delete("delete from product where id = #{id}")
    void deleteById(Integer id);
    //修改单个商品信息
    @Update("update product set title = #{title},description = #{description},type =#{type},price = #{price},status = #{status},publisher_id = #{publishId},publish_time=#{publishTime},update_time =#{updateTime} ")
     void update(Product product);
    //查询全部商品详情
    @Select("select * from product")
     List<Product> list();
    //根据id查询单个商品信息
    @Select("select *from product where id = #{id}")
     Product selectById(Integer id);



}
