package com.sun.jotang.service;

import com.sun.jotang.pojo.Product;
import com.sun.jotang.pojo.ProductOrder;
import org.springframework.transaction.annotation.Transactional;

public interface ProductOrderService {
    //建立订单
    void insert(ProductOrder order);
    @Transactional
    void update(ProductOrder order);

}
