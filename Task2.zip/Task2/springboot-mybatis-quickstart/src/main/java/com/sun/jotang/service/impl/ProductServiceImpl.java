package com.sun.jotang.service.impl;

import com.sun.jotang.mapper.ProductMapper;
import com.sun.jotang.pojo.Product;
import com.sun.jotang.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductMapper productMapper;
    //新增商品信息
    @Transactional
    @Override
    public void insert(Product product) {
        //参数校验
        if (product.getTitle() == null || product.getTitle().trim().isEmpty()) {
            throw new IllegalArgumentException("商品标题不能为空");
        }
        if (product.getPrice() <= 0 ) {
            throw new IllegalArgumentException("商品价格必须大于0");
        }
        if (product.getPublisherId() == null) {
            throw new IllegalArgumentException("发布者ID不能为空");
        }
        product.setPublishTime(LocalDateTime.now());
        product.setUpdateTime(LocalDateTime.now());
        productMapper.insert(product);


    }
    //根据id删除商品
    @Transactional
    @Override
    public void deleteById(Integer id) {
        //参数校验
        if (id == null) {
            throw new IllegalArgumentException("商品ID不能为空");
        }
        // 先查询商品是否存在
        Product product = productMapper.selectById(id);
        if (id == null) {
            throw new RuntimeException("商品不存在，无法删除");
        }
        productMapper.deleteById(id);
    }
    //修改商品信息
    @Transactional
    @Override
    public void update(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("商品ID不能为空");
        }
        // 校验商品是否存在
        if (productMapper.selectById(product.getId()) == null) {
            throw new RuntimeException("商品不存在，无法更新");}
        product.setUpdateTime(LocalDateTime.now());
            productMapper.update(product);

    }
    //查询全部商品信息
    @Override
    public List<Product> list() {
        return productMapper.list();
    }//根据id查询商品信息
    @Override
    public Product selectById(Integer id) {
        if(id==null)
            throw new IllegalArgumentException("商品id不能为空");
        return productMapper.selectById(id);

    }




}
