package com.sun.jotang.service.impl;

import com.sun.jotang.mapper.ProductMapper;
import com.sun.jotang.mapper.ProductOrderMapper;
import com.sun.jotang.pojo.Product;
import com.sun.jotang.pojo.ProductOrder;
import com.sun.jotang.service.ProductOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;


@Service
public class ProductOrderServiceImpl implements ProductOrderService {
    @Autowired
    private ProductOrderMapper productOrderMapper;
        @Override
        public void insert (ProductOrder order){
            order.setCreate_time(LocalDateTime.now());
            order.setUpdate_time(LocalDateTime.now());
            productOrderMapper.insert(order);


        }
        @Transactional
        @Override
        public void update (ProductOrder order){
            //参数校验
            if (order.getProduct_id() == null || order.getBuyer_id() == null || order.getSeller_id() == null)
                throw new IllegalArgumentException("各个Id均不能不存在");
            order.setCreate_time(LocalDateTime.now());
            order.setUpdate_time(LocalDateTime.now());
            productOrderMapper.update(order);
            }



        }
    }