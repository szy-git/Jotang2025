package com.sun.jotang.controller;

import com.sun.jotang.pojo.Product;
import com.sun.jotang.pojo.ProductOrder;
import com.sun.jotang.pojo.Result;
import com.sun.jotang.service.ProductOrderService;
import com.sun.jotang.service.ProductService;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class ProductOrderController {
    @Autowired
    private ProductOrderService orderService;
    @Autowired
    private ProductOrderService productOrderService;

    @PostMapping("order")
    public Result insert(ProductOrder order) {
        System.out.println("建立订单:");
    orderService.insert(order);
    return Result.success();
    }
    @PutMapping("order")
    public Result updateById(@RequestBody ProductOrder order){
        System.out.println("修改订单信息");
        productOrderService.update(order);
        return Result.success();
    }
}
