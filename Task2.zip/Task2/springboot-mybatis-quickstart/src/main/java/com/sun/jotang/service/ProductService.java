package com.sun.jotang.service;

import com.sun.jotang.pojo.Product;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ProductService {
    //新增商品信息
    @Transactional
    void insert(Product product);
    //删除商品信息
    @Transactional
    void deleteById(Integer id);
    //根据id修改数据
    void update(Product product);
    //查询全部商品数据
    List<Product> list();
    //根据id查询商品数据
    Product selectById(Integer id);

}
